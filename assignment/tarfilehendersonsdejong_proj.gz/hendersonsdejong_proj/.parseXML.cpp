bool XMLParser::parseXML()
{
  vector<XMLItem>::iterator iter;
  for(iter = this->theInput.begin(); iter != this->theInput.end(); ++iter)
  {
    XMLItem thisItem = *iter;

    if(thisItem.isData())
    {
      theXML.push(thisItem);
    }

    else if(this->isXML(thisItem.getItemText()) == false)
    {
      cout << "ERROR: invalid tag found." << endl;
      return false;
    }

    else if(thisItem.isOpenTag())
    {
      theXML.push(thisItem);
    }

    else //is valid close tag
    {
      XMLItem nextItem;

      if(theXML.empty())
      {
        cout << "ERROR: XML not properly nested" << endl;
        return false;
      }

      //* Pop stack until open tag *//
      nextItem = theXML.top();
      while(!nextItem.isOpenTag() && !theXML.empty())
      {
        theXML.pop();
        nextItem = theXML.top();
      }
      theXML.pop();

      if(thisItem.getItemText().substr(1) != nextItem.getItemText())
      {
        cout << "ERROR: XML not properly nested." << endl;
        return false;
